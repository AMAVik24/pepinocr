<?php

/**
 * The file that defines the Deactivator class
 *
 * A class containing activation-related logic
 */

namespace AmaSiteEssentials\Includes;


class Activator {
	
	public static function activate() {

	}
}
