<?php

/**
 * The file that defines the Deactivator class
 *
 * A class containing deactivation-related logic
 */

namespace AmaSiteEssentials\Includes;

class Deactivator {

	public static function deactivate() {

	}

}
